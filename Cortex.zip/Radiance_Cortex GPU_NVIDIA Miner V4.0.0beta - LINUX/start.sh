#version: V4.0.0

export CUDA_VISIBLE_DEVICES=1
./miner -a 0xe6d90a7363086c557f7f2953a7472bf605b43265 -p eu.frostypool.com:8008 -w $rigName


#you can select gpu by set CUDA_VISIBLE_DEVICES
#-a: the cortex account
#-p: the pool uri and port
#-w: the worker name
